import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private String nome;
    private List<Livro> livros;

    public Biblioteca(String nome) {
        this.nome = nome;
        this.livros = new ArrayList<>();
    }

    public void adicionarLivro(Livro livro) {
        livros.add(livro);
    }

    @Override
    public String toString() {
        String texto = "Biblioteca: " + nome + "\n\n";
        for (Livro l : livros) {
            texto += l + "\n";
        }
        return texto;
    }
}