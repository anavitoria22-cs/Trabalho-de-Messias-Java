public class ProgramaAssociaçao {
    public static void main(String[] args) {
        
        Autor autor1 = new Autor("J.K. Rowling");

        Livro livro1 = new Livro("Harry Potter e a Pedra Filosofal", autor1);
        
        livro1.adicionarCapitulo(new Capitulo("O Menino que Sobreviveu"));
        livro1.adicionarCapitulo(new Capitulo("O Vidro que sumiu"));

        Biblioteca biblioteca = new Biblioteca("Biblioteca Central");

        biblioteca.adicionarLivro(livro1);

        System.out.println(biblioteca);
    }
}